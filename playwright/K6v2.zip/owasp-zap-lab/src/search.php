<?php require 'header.php'; $q = $_GET['q'] ?? ''; ?>
<section class="card">
    <h2>Zoeken</h2>
    <p>Zoek in de demo-website. Deze pagina is bewust kwetsbaar: de zoekterm wordt zonder output-encoding in de HTML geplaatst.</p>
    <form method="get">
        <label for="q">Zoekterm</label>
        <input id="q" name="q" value="<?php echo $q; ?>">
        <button type="submit">Zoeken</button>
    </form>
    <?php if (isset($_GET['q'])): ?>
        <p>Je zocht naar: <strong><?php echo $q; ?></strong></p>
    <?php endif; ?>
</section>

<section class="card">
    <h2>Zelf kwetsbaarheden uitproberen</h2>
    <p>De onderstaande voorbeelden zijn bedoeld voor deze lokale oefenwebsite. Kopieer een voorbeeld naar het zoekveld en klik op <strong>Zoeken</strong>. Gebruik ze alleen op deze demo.</p>

    <h3>1. Reflected Cross-Site Scripting (XSS)</h3>
    <p>De ingevoerde zoekterm wordt direct teruggeplaatst in de pagina. Met deze test kan een JavaScript-alert in je eigen browsersessie verschijnen:</p>
    <pre><code>&lt;script&gt;alert('XSS demo')&lt;/script&gt;</code></pre>
    <p>Een alternatief dat test of HTML-attributen en event handlers worden verwerkt:</p>
    <pre><code>&lt;img src=x onerror=alert('XSS demo')&gt;</code></pre>
    <p><strong>Wat zie je?</strong> Als de browser de invoer als HTML uitvoert in plaats van als gewone tekst toont, is er sprake van onveilige uitvoer.</p>

    <h3>2. HTML-injectie</h3>
    <p>Probeer de pagina-opmaak te beïnvloeden met een HTML-element:</p>
    <pre><code>&lt;h2&gt;Deze kop komt uit mijn zoekterm&lt;/h2&gt;</code></pre>
    <p><strong>Wat zie je?</strong> De tekst verschijnt als een echte kop. Dat laat zien dat HTML-invoer niet als tekst wordt behandeld.</p>

    <h3>3. Attribuut-injectie</h3>
    <p>De zoekterm wordt ook in het <code>value</code>-attribuut van het invoerveld geplaatst. Probeer de attribuutwaarde af te sluiten:</p>
    <pre><code>" autofocus onfocus="alert('Attribuut demo')</code></pre>
    <p><strong>Wat zie je?</strong> Afhankelijk van de browser kan de toegevoegde event handler worden uitgevoerd wanneer het veld focus krijgt.</p>

    <h3>4. Parameter aanpassen</h3>
    <p>De zoekterm staat in de URL-parameter <code>q</code>. Pas de waarde na <code>?q=</code> handmatig aan en laad de pagina opnieuw. Vergelijk de URL met de weergegeven tekst en bekijk in de browserontwikkelaarstools of ZAP hoe de parameter in het HTTP-verzoek wordt verzonden.</p>

    <div class="notice"><strong>Let op:</strong> dit zijn demonstraties van invoer- en uitvoerproblemen, geen complete beveiligingstest. SQL Injection wordt op de pagina Inloggen gedemonstreerd. Voer de voorbeelden uitsluitend uit op deze lokaal draaiende oefenwebsite.</div>
</section>
<?php require 'footer.php'; ?>
