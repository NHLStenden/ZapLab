# Loadtests met k6

Deze map bevat een beperkte loadtest voor de lokale PHP/Apache-demo. De test stuurt alleen GET-verzoeken naar de vier pagina's. Er worden geen formulieren verstuurd en er wordt geen data gewijzigd.

## Veiligheidslimieten

- Alleen `localhost`, `127.0.0.1` en `::1` zijn toegestaan als target.
- De test bouwt geleidelijk op tot maximaal 5 virtuele gebruikers.
- De totale testduur is 60 seconden.
- Gebruik dit script uitsluitend op de lokale oefenwebsite, niet op gedeelde of publieke omgevingen.

## Installatie

Installeer k6 op je hostcomputer volgens de officiële installatie-instructies van Grafana k6: https://grafana.com/docs/k6/latest/set-up/install-k6/.

Start eerst de website vanuit de hoofdmap:

```bash
docker compose up -d --build
```

Controleer dat `http://localhost:8080` bereikbaar is en voer daarna vanuit de hoofdmap uit:

```bash
k6 run load/k6.js
```

Optioneel kan een andere loopback-adresnotatie worden opgegeven:

```bash
k6 run -e BASE_URL=http://localhost:8080 load/k6.js
```

Een niet-lokaal adres wordt door de configuratie geweigerd.

## Resultaten interpreteren

k6 toont onder meer:

- `http_req_duration`: responstijd van HTTP-verzoeken, inclusief p95.
- `http_req_failed`: aandeel HTTP-verzoeken met een foutstatus of netwerkfout.
- `checks`: percentage geslaagde controles voor HTTP 200 en HTML-responses.
- `vus`: aantal gelijktijdige virtuele gebruikers.

De thresholds zijn startwaarden voor een kleine lokale demo, geen SLA of productiebenchmark. Resultaten hangen af van hardware, Docker-configuratie en achtergrondbelasting.
